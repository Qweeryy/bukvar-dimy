# Букварь для Димы — Android

Веб-приложение обёрнуто в **Capacitor**.  
Голос: **онлайн API** (Yandex / OpenAI), если нет сети или ключа — **голос телефона**.

## Что уже сделано в www/

- Гибридный TTS (`auto` / `yandex` / `openai` / `device`)
- Настройки: API-ключ и голос (хранятся только на устройстве)
- Кэш коротких фраз, чтобы не жечь API
- Офлайн: `speechSynthesis` / системный русский голос Android

## Сборка APK (на компьютере)

Нужны: Node.js 18+, Android Studio (SDK 34+).

```bash
cd bukvar_android
npm install
npx cap add android
npx cap sync android
npx cap open android
```

В Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Или из CLI (если настроен `gradlew`):

```bash
cd android
./gradlew assembleDebug
# APK: android/app/build/outputs/apk/debug/app-debug.apk
```

## Микрофон

В `AndroidManifest.xml` после `cap add` проверь разрешения:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
```

Capacitor обычно подхватывает их из WebView getUserMedia; если нет — добавь вручную.

## Настройка голоса в приложении

1. Открой **Настройки**
2. **Голос учителя** → «Авто» или «Yandex» / «OpenAI»
3. Вставь **API-ключ**
4. Голос: Yandex `alena` / `filipp` / `jane`; OpenAI `nova` / `shimmer` / `onyx`
5. **Проверить голос**

Без ключа или без интернета — автоматически голос телефона.

## Ключи

- Yandex: https://console.yandex.cloud/ → SpeechKit → API-ключ  
- OpenAI: https://platform.openai.com/api-keys  

Ключ **не** попадает на наш сервер — только `localStorage` на телефоне.

const CACHE='dima-bukvar-v7-25';
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil((async()=>{
  const keys=await caches.keys();
  await Promise.all(keys.filter(k=>k.startsWith('dima-bukvar-')&&k!==CACHE).map(k=>caches.delete(k)));
  await self.clients.claim();
})()));
self.addEventListener('fetch',e=>{
 const u=e.request.url;
 // Keep the heavy Vosk assets cached, but NEVER cache-first the app HTML.
 if(u.includes('vosk-browser')||u.includes('vosk-model-small-ru')){
  e.respondWith(caches.open(CACHE).then(async c=>{
   const hit=await c.match(e.request); if(hit)return hit;
   const r=await fetch(e.request); if(r&&r.ok)c.put(e.request,r.clone()).catch(()=>{}); return r;
  }));
  return;
 }
 if(e.request.mode==='navigate'||u.endsWith('/index.html')||u.endsWith('/')){
  e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));
 }
});
